export function NamedComponents() {
  return (
    
  );
}